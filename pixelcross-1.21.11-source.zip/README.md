# PixelCross (Fabric, Minecraft 1.21.11)

A custom crosshair: 6 presets, 15x15 pixel editor, colors, color change when aiming at an entity,
outline, size, attack cooldown bar, copy/paste codes. Press Right Shift in game (rebindable).

STATUS: not yet compiled against Minecraft or tested in game.

## Build
Option A (your PC): install JDK 21 and Gradle 9.2.1, then run `gradle build` in this folder.
Option B (GitHub): upload this whole folder (including .github) to a new repository,
open Actions, run "build", and download the "pixelcross" artifact.

The jar is in build/libs. Use the one without "-sources".

## Install
Fabric Loader + Fabric API for 1.21.11, then put the jar in the mods folder.
Disable other crosshair mods (including Lunar's crosshair).

## Vulkan
Vanilla 1.21.11 is OpenGL only. VulkanMod adds Vulkan. This mod makes no direct OpenGL calls,
but it has not been tested with VulkanMod. VulkanMod replaces the renderer, so use a separate
profile without Sodium or Iris. Test without VulkanMod first.
