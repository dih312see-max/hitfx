package dev.pixelcross;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.GameType;
import org.lwjgl.glfw.GLFW;

public final class PixelCross implements ClientModInitializer {
    public static Config config;

    @Override
    public void onInitializeClient() {
        config = Config.load();

        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath("pixelcross", "main"));
        KeyMapping open = KeyBindingHelper.registerKeyBinding(
                new KeyMapping("key.pixelcross.open", GLFW.GLFW_KEY_RIGHT_SHIFT, category));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (open.consumeClick()) {
                if (client.screen == null) client.setScreen(new EditorScreen());
            }
        });

        HudElementRegistry.replaceElement(VanillaHudElements.CROSSHAIR, vanilla -> (graphics, delta) -> {
            Minecraft mc = Minecraft.getInstance();
            // Keep vanilla behaviour when disabled, in F3, third person or spectator.
            if (!config.enabled
                    || mc.player == null
                    || mc.gameMode == null
                    || mc.gameMode.getPlayerMode() == GameType.SPECTATOR
                    || mc.getDebugOverlay().showDebugScreen()
                    || !mc.options.getCameraType().isFirstPerson()) {
                vanilla.render(graphics, delta);
                return;
            }
            draw(graphics, mc);
        });
    }

    private static void draw(GuiGraphics g, Minecraft mc) {
        boolean[] p = Shape.decode(config.pixels);
        if (p == null) return;

        boolean targeting = config.highlightTarget && mc.crosshairPickEntity != null;
        int argb = 0xFF000000 | (targeting ? config.targetColor : config.color);
        int s = config.scale;
        float inverse = 1.0f / (float) mc.getWindow().getGuiScale();

        // Draw in real screen pixels so GUI scale does not change the crosshair size.
        g.pose().pushMatrix();
        g.pose().scale(inverse, inverse);
        int left = mc.getWindow().getWidth() / 2 - (Shape.SIZE * s) / 2;
        int top = mc.getWindow().getHeight() / 2 - (Shape.SIZE * s) / 2;
        paint(g, p, left, top, s, argb, config.outline);

        if (config.cooldownBar) {
            float charge = mc.player.getAttackStrengthScale(0.0f);
            if (charge < 1.0f) {
                int width = Shape.SIZE * s;
                int y = top + Shape.SIZE * s + 3;
                g.fill(left, y, left + width, y + s, 0x80000000);
                g.fill(left, y, left + (int) (width * charge), y + s, argb);
            }
        }
        g.pose().popMatrix();
    }

    static void paint(GuiGraphics g, boolean[] p, int left, int top, int s, int argb, boolean outline) {
        if (outline) {
            for (int y = 0; y < Shape.SIZE; y++)
                for (int x = 0; x < Shape.SIZE; x++)
                    if (Shape.get(p, x, y))
                        g.fill(left + x * s - 1, top + y * s - 1,
                               left + (x + 1) * s + 1, top + (y + 1) * s + 1, 0xFF000000);
        }
        for (int y = 0; y < Shape.SIZE; y++)
            for (int x = 0; x < Shape.SIZE; x++)
                if (Shape.get(p, x, y))
                    g.fill(left + x * s, top + y * s, left + (x + 1) * s, top + (y + 1) * s, argb);
    }
}
