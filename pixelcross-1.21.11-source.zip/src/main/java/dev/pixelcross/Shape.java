package dev.pixelcross;

/** The crosshair as a square pixel grid. No Minecraft classes, so it can be tested alone. */
public final class Shape {
    public static final int SIZE = 15;
    public static final int MID = SIZE / 2;
    public static final String[] PRESETS = {"Cross", "Dot", "Cross + dot", "T", "Circle", "X"};

    private Shape() {}

    public static boolean[] preset(int index) {
        boolean[] p = new boolean[SIZE * SIZE];
        for (int y = 0; y < SIZE; y++) {
            for (int x = 0; x < SIZE; x++) {
                int dx = x - MID, dy = y - MID;
                int ax = Math.abs(dx), ay = Math.abs(dy);
                boolean arms = (dx == 0 && ay >= 2 && ay <= 5) || (dy == 0 && ax >= 2 && ax <= 5);
                p[y * SIZE + x] = switch (index) {
                    case 1 -> ax <= 1 && ay <= 1;
                    case 2 -> arms || (dx == 0 && dy == 0);
                    case 3 -> arms && !(dx == 0 && dy < 0);
                    case 4 -> Math.round(Math.sqrt(dx * dx + dy * dy)) == 5;
                    case 5 -> ax == ay && ax >= 2 && ax <= 4;
                    default -> arms;
                };
            }
        }
        return p;
    }

    public static String encode(boolean[] p) {
        StringBuilder s = new StringBuilder(p.length);
        for (boolean b : p) s.append(b ? '1' : '0');
        return s.toString();
    }

    /** Returns null if the text is not a valid crosshair code. */
    public static boolean[] decode(String s) {
        if (s == null) return null;
        s = s.trim();
        if (!s.matches("[01]{" + (SIZE * SIZE) + "}")) return null;
        boolean[] p = new boolean[SIZE * SIZE];
        for (int i = 0; i < p.length; i++) p[i] = s.charAt(i) == '1';
        return p;
    }

    public static boolean get(boolean[] p, int x, int y) {
        return x >= 0 && y >= 0 && x < SIZE && y < SIZE && p[y * SIZE + x];
    }
}
