package dev.pixelcross;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.function.Supplier;

/** Left click paints, right click erases. */
public final class EditorScreen extends Screen {
    private static final int CELL = 10;
    private static final int[] COLORS = {0xFFFFFF, 0x00FF00, 0x00FFFF, 0xFFFF00, 0xFF00FF, 0xFF4040, 0x000000};
    private static final String[] COLOR_NAMES = {"White", "Green", "Cyan", "Yellow", "Magenta", "Red", "Black"};

    private int gridLeft, gridTop;
    private int presetIndex;
    private String status = "";

    public EditorScreen() {
        super(Component.literal("PixelCross editor"));
    }

    @Override
    protected void init() {
        Config c = PixelCross.config;
        gridLeft = width / 2 - 160;
        gridTop = Math.max(24, height / 2 - 80);
        int x = width / 2 + 10;
        int y = gridTop;

        toggle(x, y, () -> "Enabled: " + onOff(c.enabled), () -> c.enabled = !c.enabled);
        toggle(x, y += 22, () -> "Preset: " + Shape.PRESETS[presetIndex], () -> {
            presetIndex = (presetIndex + 1) % Shape.PRESETS.length;
            c.pixels = Shape.encode(Shape.preset(presetIndex));
        });
        toggle(x, y += 22, () -> "Color: " + colorName(c.color), () -> c.color = nextColor(c.color));
        toggle(x, y += 22, () -> "Target color: " + (c.highlightTarget ? colorName(c.targetColor) : "OFF"), () -> {
            if (!c.highlightTarget) {
                c.highlightTarget = true;
                c.targetColor = COLORS[0];
            } else if (c.targetColor == COLORS[COLORS.length - 1]) {
                c.highlightTarget = false;
            } else {
                c.targetColor = nextColor(c.targetColor);
            }
        });
        toggle(x, y += 22, () -> "Size: " + c.scale + "x", () -> c.scale = c.scale % 6 + 1);
        toggle(x, y += 22, () -> "Outline: " + onOff(c.outline), () -> c.outline = !c.outline);
        toggle(x, y += 22, () -> "Cooldown bar: " + onOff(c.cooldownBar), () -> c.cooldownBar = !c.cooldownBar);

        y += 22;
        addRenderableWidget(Button.builder(Component.literal("Copy code"), b -> {
            minecraft.keyboardHandler.setClipboard(c.pixels);
            status = "Copied";
        }).bounds(x, y, 73, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Paste code"), b -> {
            String text = minecraft.keyboardHandler.getClipboard();
            if (Shape.decode(text) != null) {
                c.pixels = text.trim();
                status = "Imported";
            } else {
                status = "Invalid code";
            }
        }).bounds(x + 77, y, 73, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Clear"),
                b -> c.pixels = "0".repeat(Shape.SIZE * Shape.SIZE)).bounds(x, y + 22, 73, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(x + 77, y + 22, 73, 20).build());
    }

    private void toggle(int x, int y, Supplier<String> label, Runnable action) {
        addRenderableWidget(Button.builder(Component.literal(label.get()), b -> {
            action.run();
            b.setMessage(Component.literal(label.get()));
        }).bounds(x, y, 150, 20).build());
    }

    private static String onOff(boolean value) {
        return value ? "ON" : "OFF";
    }

    private static int colorIndex(int color) {
        for (int i = 0; i < COLORS.length; i++) if (COLORS[i] == color) return i;
        return -1;
    }

    private static String colorName(int color) {
        int i = colorIndex(color);
        return i < 0 ? String.format("#%06X", color) : COLOR_NAMES[i];
    }

    private static int nextColor(int color) {
        return COLORS[(colorIndex(color) + 1) % COLORS.length];
    }

    private boolean edit(double mx, double my, int button) {
        if (button != 0 && button != 1) return false;
        int x = (int) Math.floor((mx - gridLeft) / CELL);
        int y = (int) Math.floor((my - gridTop) / CELL);
        if (x < 0 || y < 0 || x >= Shape.SIZE || y >= Shape.SIZE) return false;
        boolean[] p = Shape.decode(PixelCross.config.pixels);
        if (p == null) return false;
        p[y * Shape.SIZE + x] = button == 0;
        PixelCross.config.pixels = Shape.encode(p);
        return true;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        return edit(event.x(), event.y(), event.button()) || super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        return edit(event.x(), event.y(), event.button()) || super.mouseDragged(event, dx, dy);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        super.render(g, mouseX, mouseY, delta);
        g.drawCenteredString(font, title, width / 2, gridTop - 16, 0xFFFFFFFF);
        boolean[] p = Shape.decode(PixelCross.config.pixels);
        if (p == null) return;
        for (int y = 0; y < Shape.SIZE; y++) {
            for (int x = 0; x < Shape.SIZE; x++) {
                int left = gridLeft + x * CELL, top = gridTop + y * CELL;
                int empty = (x == Shape.MID || y == Shape.MID) ? 0xFF505050 : 0xFF303030;
                g.fill(left, top, left + CELL - 1, top + CELL - 1,
                        Shape.get(p, x, y) ? 0xFF000000 | PixelCross.config.color : empty);
            }
        }
        g.drawString(font, "L-click: draw  R-click: erase", gridLeft, gridTop + Shape.SIZE * CELL + 4, 0xFFCCCCCC);
        g.drawString(font, status, gridLeft, gridTop + Shape.SIZE * CELL + 16, 0xFFCCCCCC);
    }

    @Override
    public void removed() {
        PixelCross.config.save();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
