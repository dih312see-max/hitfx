package dev.pixelcross;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public boolean enabled = true;
    public String pixels = Shape.encode(Shape.preset(0));
    public int color = 0xFFFFFF;
    public int targetColor = 0xFF4040;
    public boolean highlightTarget = true;
    public boolean outline = true;
    public boolean cooldownBar = true;
    public int scale = 2;

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("pixelcross.json");
    }

    public static Config load() {
        try {
            if (Files.exists(file())) {
                Config c = GSON.fromJson(Files.readString(file()), Config.class);
                if (c != null) {
                    if (Shape.decode(c.pixels) == null) c.pixels = Shape.encode(Shape.preset(0));
                    c.scale = Math.max(1, Math.min(6, c.scale));
                    return c;
                }
            }
        } catch (IOException | RuntimeException e) {
            System.err.println("[PixelCross] Could not read config: " + e);
        }
        return new Config();
    }

    public void save() {
        try {
            Files.writeString(file(), GSON.toJson(this));
        } catch (IOException e) {
            System.err.println("[PixelCross] Could not save config: " + e);
        }
    }
}
