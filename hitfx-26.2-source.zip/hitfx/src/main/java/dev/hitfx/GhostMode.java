package dev.hitfx;

public enum GhostMode {
	SPRINTING, MOVING
}
