package dev.hitfx;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.function.Supplier;

public final class MenuScreen extends Screen {
	private final boolean extras;
	private int row;

	public MenuScreen() {
		this(false);
	}

	private MenuScreen(boolean extras) {
		super(Component.literal(extras ? "HitFX: Afterimages and Smooth KB" : "HitFX"));
		this.extras = extras;
	}

	@Override
	protected void init() {
		Config c = HitFxClient.config;
		row = 0;

		if (extras) {
			initExtras(c);
		} else {
			initMain(c);
		}

		addRenderableWidget(Button.builder(Component.literal(extras ? "Hit effects..." : "Afterimages / KB..."), button -> {
			c.save();
			minecraft.gui.setScreen(new MenuScreen(!extras));
		}).bounds(width / 2 - 154, 40 + 6 * 22 + 4, 150, 20).build());

		addRenderableWidget(Button.builder(Component.literal("Done"), button -> onClose())
				.bounds(width / 2 + 4, 40 + 6 * 22 + 4, 150, 20).build());
	}

	private void initExtras(Config c) {
		option(() -> "Afterimages: " + onOff(c.afterimages), () -> c.afterimages = !c.afterimages);
		option(() -> "Green: " + onOff(c.greenAfterimages), () -> c.greenAfterimages = !c.greenAfterimages);
		option(() -> "Color if green off: " + name(c.otherColor), () -> c.otherColor = next(c.otherColor));
		option(() -> "Show when: " + name(c.ghostMode), () -> c.ghostMode = next(c.ghostMode));
		option(() -> "Trail length: " + c.ghostLength,
				() -> c.ghostLength = c.ghostLength >= 30 ? 6 : c.ghostLength + 4);
		option(() -> "Smooth KB: " + onOff(c.smoothKnockback), () -> c.smoothKnockback = !c.smoothKnockback);
		option(() -> "KB smoothness: " + c.smoothStrength,
				() -> c.smoothStrength = c.smoothStrength >= 5 ? 1 : c.smoothStrength + 1);
	}

	private void initMain(Config c) {

		option(() -> "Hit particles: " + name(c.hitParticle), () -> c.hitParticle = next(c.hitParticle));
		option(() -> "Hit sound: " + name(c.hitSound), () -> c.hitSound = next(c.hitSound));
		option(() -> "Kill effect: " + name(c.killEffect), () -> c.killEffect = next(c.killEffect));
		option(() -> "Walk trail: " + name(c.trail), () -> c.trail = next(c.trail));
		option(() -> "Particle amount: " + c.particleAmount,
				() -> c.particleAmount = c.particleAmount >= 40 ? 5 : c.particleAmount + 5);
		option(() -> "Hit marker: " + onOff(c.hitMarker), () -> c.hitMarker = !c.hitMarker);
		option(() -> "Combo counter: " + onOff(c.comboCounter), () -> c.comboCounter = !c.comboCounter);
		option(() -> "Hurt flash: " + onOff(c.hurtFlash), () -> c.hurtFlash = !c.hurtFlash);
		option(() -> "Info HUD: " + onOff(c.infoHud), () -> c.infoHud = !c.infoHud);
		option(() -> "Keystrokes: " + onOff(c.keystrokes), () -> c.keystrokes = !c.keystrokes);
		option(() -> "Armor HUD: " + onOff(c.armorHud), () -> c.armorHud = !c.armorHud);
	}

	private void option(Supplier<String> label, Runnable change) {
		int x = width / 2 + (row % 2 == 0 ? -154 : 4);
		int y = 40 + (row / 2) * 22;
		row++;

		addRenderableWidget(Button.builder(Component.literal(label.get()), button -> {
			change.run();
			button.setMessage(Component.literal(label.get()));
		}).bounds(x, y, 150, 20).build());
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		super.extractRenderState(graphics, mouseX, mouseY, delta);
		graphics.centeredText(font, title, width / 2, 20, 0xFFFFFFFF);
	}

	@Override
	public void onClose() {
		HitFxClient.config.save();
		super.onClose();
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	private static <E extends Enum<E>> E next(E value) {
		E[] values = value.getDeclaringClass().getEnumConstants();
		return values[(value.ordinal() + 1) % values.length];
	}

	private static String name(Enum<?> value) {
		return value.name().replace('_', ' ');
	}

	private static String onOff(boolean value) {
		return value ? "ON" : "OFF";
	}
}
