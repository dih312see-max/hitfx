package dev.hitfx;

import net.fabricmc.fabric.api.client.rendering.v1.level.LevelExtractionContext;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;

/**
 * Eases the first-person camera for a moment after you are hurt. Only the
 * rendered view moves. Your velocity, position and packets are never changed.
 */
public final class SmoothKnockback {
	private static final long WINDOW_MS = 600;
	private static final double MAX_OFFSET = 0.35;

	private static int lastHurtTime;
	private static long hurtAt;
	private static long lastFrame;
	private static Vec3 smooth;

	private SmoothKnockback() {
	}

	public static void tick(Minecraft client) {
		if (client.player == null) return;
		int hurtTime = client.player.hurtTime;
		if (hurtTime > lastHurtTime) hurtAt = System.currentTimeMillis();
		lastHurtTime = hurtTime;
	}

	public static void apply(LevelExtractionContext context) {
		Config config = HitFxClient.config;
		Minecraft client = Minecraft.getInstance();
		Vec3 actual = context.levelState().cameraRenderState.pos;
		long now = System.currentTimeMillis();
		long since = now - hurtAt;
		double elapsed = Math.min(100, now - lastFrame);
		lastFrame = now;

		if (!config.smoothKnockback || client.player == null || !client.options.getCameraType().isFirstPerson()
				|| smooth == null || smooth.distanceToSqr(actual) > 4.0) {
			smooth = actual;
			return;
		}

		if (since >= WINDOW_MS) {
			smooth = actual;
			return;
		}

		// Frame-rate independent easing. Higher strength means a slower catch-up.
		double timeConstant = 15.0 + config.smoothStrength * 15.0;
		double blend = 1.0 - Math.exp(-elapsed / timeConstant);
		smooth = smooth.add(actual.subtract(smooth).scale(blend));

		Vec3 offset = smooth.subtract(actual);
		double length = offset.length();
		if (length > MAX_OFFSET) offset = offset.scale(MAX_OFFSET / length);

		// Fade out over the second half so the view never snaps back.
		double fade = Math.min(1.0, 2.0 * (WINDOW_MS - since) / WINDOW_MS);
		context.levelState().cameraRenderState.pos = actual.add(offset.scale(fade));
	}
}
