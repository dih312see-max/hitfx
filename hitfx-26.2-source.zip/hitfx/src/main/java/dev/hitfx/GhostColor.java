package dev.hitfx;

/** Used when the green option is off. */
public enum GhostColor {
	WHITE(0xFFFFFF), CYAN(0x00E5FF), BLUE(0x3355FF), PURPLE(0xB44CFF),
	PINK(0xFF4FC3), RED(0xFF3333), ORANGE(0xFF9900), RAINBOW(-1);

	public final int rgb;

	GhostColor(int rgb) {
		this.rgb = rgb;
	}
}
