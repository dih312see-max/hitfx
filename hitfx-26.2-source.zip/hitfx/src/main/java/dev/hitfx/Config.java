package dev.hitfx;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Saved to config/hitfx.json. */
public final class Config {
	public HitParticle hitParticle = HitParticle.MAGIC;
	public HitSound hitSound = HitSound.DING;
	public KillEffect killEffect = KillEffect.TOTEM;
	public Trail trail = Trail.OFF;
	public int particleAmount = 15;

	public boolean hitMarker = true;
	public boolean comboCounter = true;
	public boolean hurtFlash = true;
	public boolean infoHud = true;
	public boolean keystrokes = true;
	public boolean armorHud = true;

	public boolean afterimages = true;
	public boolean greenAfterimages = true;
	public GhostColor otherColor = GhostColor.CYAN;
	public GhostMode ghostMode = GhostMode.SPRINTING;
	public int ghostLength = 14;
	public boolean smoothKnockback = true;
	public int smoothStrength = 3;

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	private static Path path() {
		return FabricLoader.getInstance().getConfigDir().resolve("hitfx.json");
	}

	public static Config load() {
		Config config = null;

		try {
			if (Files.exists(path())) {
				config = GSON.fromJson(Files.readString(path()), Config.class);
			}
		} catch (IOException | RuntimeException e) {
			System.err.println("[HitFX] Could not read config, using defaults: " + e);
		}

		if (config == null) config = new Config();
		config.repair();
		return config;
	}

	/** Gson leaves unknown enum names as null, so put defaults back. */
	private void repair() {
		if (hitParticle == null) hitParticle = HitParticle.MAGIC;
		if (hitSound == null) hitSound = HitSound.DING;
		if (killEffect == null) killEffect = KillEffect.TOTEM;
		if (trail == null) trail = Trail.OFF;
		if (otherColor == null) otherColor = GhostColor.CYAN;
		if (ghostMode == null) ghostMode = GhostMode.SPRINTING;
		ghostLength = Math.max(6, Math.min(30, ghostLength));
		smoothStrength = Math.max(1, Math.min(5, smoothStrength));
		particleAmount = Math.max(5, Math.min(40, particleAmount));
	}

	public void save() {
		try {
			Files.writeString(path(), GSON.toJson(this));
		} catch (IOException e) {
			System.err.println("[HitFX] Could not save config: " + e);
		}
	}
}
