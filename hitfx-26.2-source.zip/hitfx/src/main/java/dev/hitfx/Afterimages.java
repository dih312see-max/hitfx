package dev.hitfx;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderContext;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayDeque;

/**
 * Sandevistan-style afterimages of your own player, drawn as see-through blocky
 * silhouettes. Purely visual: game speed and movement are never touched.
 */
public final class Afterimages {
	private record Ghost(double x, double y, double z, float yaw, float swing, boolean crouching,
			int born, int hue) {
	}

	private static final ArrayDeque<Ghost> ghosts = new ArrayDeque<>();
	private static int clock;
	private static int made;
	private static Object lastLevel;

	// Corner indices for the six faces. Bit 0 = x, bit 1 = y, bit 2 = z.
	private static final int[][] FACES = {
			{0, 1, 3, 2}, {5, 4, 6, 7}, {4, 0, 2, 6},
			{1, 5, 7, 3}, {2, 3, 7, 6}, {4, 5, 1, 0}
	};

	private Afterimages() {
	}

	public static void tick(Minecraft client) {
		Config config = HitFxClient.config;

		if (client.level != lastLevel) {
			lastLevel = client.level;
			ghosts.clear();
		}

		clock++;

		while (!ghosts.isEmpty() && clock - ghosts.peekFirst().born() >= config.ghostLength) {
			ghosts.removeFirst();
		}

		LocalPlayer player = client.player;

		if (!config.afterimages) {
			ghosts.clear();
			return;
		}

		if (player == null || clock % 2 != 0) return;
		if (player.isSpectator() || player.isInvisible() || player.isPassenger()) return;
		// The silhouette is upright, so skip poses where you lie flat.
		if (player.isSwimming() || player.isFallFlying() || player.isSleeping()) return;
		if (player.getDeltaMovement().horizontalDistanceSqr() < 0.002) return;
		if (config.ghostMode == GhostMode.SPRINTING && !player.isSprinting()) return;

		float amount = Math.min(1.0F, player.walkAnimation.speed());
		float swing = (float) Math.cos(player.walkAnimation.position() * 0.6662F) * 1.1F * amount;

		ghosts.addLast(new Ghost(player.getX(), player.getY(), player.getZ(),
				player.yBodyRot, swing, player.isCrouching(), clock, made++));
	}

	public static void render(LevelRenderContext context) {
		Config config = HitFxClient.config;
		if (!config.afterimages || ghosts.isEmpty()) return;

		Vec3 camera = context.levelState().cameraRenderState.pos;
		PoseStack poseStack = context.poseStack();

		for (Ghost ghost : ghosts) {
			double dx = ghost.x() - camera.x;
			double dy = ghost.y() - camera.y;
			double dz = ghost.z() - camera.z;

			// Don't block your own view in first person.
			if (dx * dx + dz * dz < 1.44 && dy > -2.5 && dy < 0.5) continue;

			float life = 1.0F - (float) (clock - ghost.born()) / config.ghostLength;
			int alpha = (int) (Math.max(0.0F, Math.min(1.0F, life)) * 110);
			int color = (alpha << 24) | color(config, ghost);

			poseStack.pushPose();
			poseStack.translate(dx, dy, dz);
			context.submitNodeCollector().submitCustomGeometry(poseStack, RenderTypes.debugFilledBox(),
					(pose, buffer) -> silhouette(pose, buffer, ghost, color));
			poseStack.popPose();
		}
	}

	private static int color(Config config, Ghost ghost) {
		if (config.greenAfterimages) return 0x39FF14;
		if (config.otherColor != GhostColor.RAINBOW) return config.otherColor.rgb;
		return java.awt.Color.HSBtoRGB((ghost.hue() % 12) / 12.0F, 0.85F, 1.0F) & 0xFFFFFF;
	}

	/** Sizes are in skin pixels, matching the normal player shape. */
	private static void silhouette(PoseStack.Pose pose, VertexConsumer buffer, Ghost g, int color) {
		float swing = g.swing();
		part(pose, buffer, g, color, -3.9F, 0, -2, -0.1F, 12, 2, 12, swing);
		part(pose, buffer, g, color, 0.1F, 0, -2, 3.9F, 12, 2, 12, -swing);
		part(pose, buffer, g, color, -4, 12.1F, -2, 4, 23.9F, 2, 0, 0);
		part(pose, buffer, g, color, -8, 12, -2, -4.1F, 24, 2, 22, -swing);
		part(pose, buffer, g, color, 4.1F, 12, -2, 8, 24, 2, 22, swing);
		part(pose, buffer, g, color, -4, 24, -4, 4, 32, 4, 0, 0);
	}

	/** One box, optionally swung forwards or back around a pivot height. */
	private static void part(PoseStack.Pose pose, VertexConsumer buffer, Ghost g, int color,
			float x0, float y0, float z0, float x1, float y1, float z1, float pivot, float angle) {
		float scale = 0.9375F / 16.0F;
		float height = g.crouching() ? 0.83F : 1.0F;
		double yaw = Math.toRadians(g.yaw());
		float sinYaw = (float) Math.sin(yaw);
		float cosYaw = (float) Math.cos(yaw);
		float sin = (float) Math.sin(angle);
		float cos = (float) Math.cos(angle);
		float[][] corners = new float[8][];

		for (int i = 0; i < 8; i++) {
			float x = (i & 1) == 0 ? x0 : x1;
			float y = (i & 2) == 0 ? y0 : y1;
			float z = (i & 4) == 0 ? z0 : z1;
			float swungY = pivot + (y - pivot) * cos - z * sin;
			float swungZ = (y - pivot) * sin + z * cos;

			// Yaw 0 faces +Z, matching Minecraft.
			corners[i] = new float[] {
					(x * cosYaw - swungZ * sinYaw) * scale,
					swungY * scale * height,
					(x * sinYaw + swungZ * cosYaw) * scale
			};
		}

		for (int[] face : FACES) {
			for (int index : face) {
				float[] c = corners[index];
				buffer.addVertex(pose, c[0], c[1], c[2]).setColor(color);
			}
		}
	}
}
